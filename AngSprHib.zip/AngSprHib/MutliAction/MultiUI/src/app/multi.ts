export class Multi {
    id : number;
    task : string;
    taskDetails :string;
    priority :string;
    status : string
}
