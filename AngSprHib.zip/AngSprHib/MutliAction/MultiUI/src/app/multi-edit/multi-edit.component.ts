import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';

@Component({
  selector: 'app-multi-edit',
  templateUrl: './multi-edit.component.html',
  styleUrls: ['./multi-edit.component.css']
})
export class MultiEditComponent implements OnInit {

  multi: any;
  
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute, private location: Location) { }

  ngOnInit() {
    this.getMulti(this.route.snapshot.params['id']);
  }

  getMulti(id) {
    this.http.get('/multis/'+id).subscribe(data => {
      this.multi = data;
    });
  }

  updateMulti(id, data) {
    console.log(data);
    this.http.put('/multis/'+id, data)
      .subscribe(res => {
          let id = res['id'];
          this.router.navigate(['/multi-detail', id]);
        }, (err) => {
          console.log(err);
        }
      );
  }

  cancel() {
    this.location.back();
  }

}
