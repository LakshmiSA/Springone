import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-multi',
  templateUrl: './multi.component.html',
  styleUrls: ['./multi.component.css']
})
export class MultiComponent implements OnInit {

  multis : any;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.http.get('/multis').subscribe(data => {
      this.multis = data;
    });
  }

  selectedStatus: string = '';
  selectedPriority: string = '';

  //event handler for the select element's change event
  selectChangeHandler (event: any) {
    //update the ui
    this.selectedStatus = event.target.value;
    this.http.get('/multis/status/'+this.selectedStatus).subscribe(data => {
      this.multis = data;
    });  
  }

  //event handler for the select element's change event
  changeHandler (event: any) {
    //update the ui
    this.selectedPriority = event.target.value;
    this.http.get('/multis/priority/'+this.selectedPriority).subscribe(data => {
      this.multis = data;
    });  
  }

}