import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiCreateComponent } from './multi-create.component';

describe('MultiCreateComponent', () => {
  let component: MultiCreateComponent;
  let fixture: ComponentFixture<MultiCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
