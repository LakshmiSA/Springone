import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Location } from '@angular/common';
import { Multi } from '../multi';

@Component({
  selector: 'app-multi-create',
  templateUrl: './multi-create.component.html',
  styleUrls: ['./multi-create.component.css']
})
export class MultiCreateComponent implements OnInit {

  
  
  multi =new Multi();
  
  constructor(private http: HttpClient, private router: Router, private location: Location) { }

  ngOnInit() {
    
  }

  saveMulti(multi :Multi) {
   
    console.log('sdsddsd...');
    console.log(JSON.stringify(multi.taskDetails));
    const httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });
    this.http.post('/multis', JSON.stringify(multi), {headers: httpHeaders})
      .subscribe(res => {
          this.router.navigate(['/multi']);
        }, (err) => {
          console.log(err);
        }
      );
  }

  cancel() {
    this.location.back();
  }
}