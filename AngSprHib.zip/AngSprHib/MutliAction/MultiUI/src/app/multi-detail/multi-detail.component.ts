import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-multi-detail',
  templateUrl: './multi-detail.component.html',
  styleUrls: ['./multi-detail.component.css']
})
export class MultiDetailComponent implements OnInit {

  multi: any;
  
  constructor(private router: Router, private route: ActivatedRoute, private http: HttpClient, private location: Location) { }

  ngOnInit() {
    this.getMultiDetail(this.route.snapshot.params['id']);
  }

  getMultiDetail(id) {
    this.http.get('/multis/'+id).subscribe(data => {
      this.multi = data;
    });
  }

  deleteMulti(id) {
    this.http.delete('/multis/'+id)
      .subscribe(res => {
          this.router.navigate(['/multi']);
        }, (err) => {
          console.log(err);
        }
      );
  }

  cancel() {
    this.location.back();
  }
}