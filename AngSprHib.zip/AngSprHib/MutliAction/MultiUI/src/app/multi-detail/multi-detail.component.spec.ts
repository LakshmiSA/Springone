import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiDetailComponent } from './multi-detail.component';

describe('MultiDetailComponent', () => {
  let component: MultiDetailComponent;
  let fixture: ComponentFixture<MultiDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
