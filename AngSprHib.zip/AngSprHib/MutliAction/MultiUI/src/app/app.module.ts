import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { MultiComponent } from './multi/multi.component';
import { MultiDetailComponent } from './multi-detail/multi-detail.component';
import { MultiCreateComponent } from './multi-create/multi-create.component';
import { MultiEditComponent } from './multi-edit/multi-edit.component';
import { Location } from '@angular/common';
const appRoutes: Routes = [
  {
    path: 'multi',
    component: MultiComponent,
    data: { title: 'Multi List' }
  },
  {
    path: 'multi-detail/:id',
    component: MultiDetailComponent,
    data: { title: 'Multi Details' }
  },
  {
    path: 'multi-create',
    component: MultiCreateComponent,
    data: { title: 'Create Multi' }
  },
  {
    path: 'multi-edit/:id',
    component: MultiEditComponent,
    data: { title: 'Edit Multi' }
  },
  { path: '',
    redirectTo: '/multi',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    MultiComponent,
    MultiDetailComponent,
    MultiCreateComponent,
    MultiEditComponent
  ],
  imports: [
    BrowserModule,
	  FormsModule,
	  HttpClientModule,
	  RouterModule.forRoot(
    appRoutes,
    { enableTracing: true } // <-- debugging purposes only
	)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
