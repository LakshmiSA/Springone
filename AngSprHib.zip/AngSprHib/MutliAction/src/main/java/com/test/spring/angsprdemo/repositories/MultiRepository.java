package com.test.spring.angsprdemo.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.test.spring.angsprdemo.models.Multi;

public interface MultiRepository  extends CrudRepository<Multi, String> {
    	
	@Override
	void delete(Multi deleted);
	
	public List<Multi> findByStatus(String name);
	
	public List<Multi> findByPriority(String name);
}
