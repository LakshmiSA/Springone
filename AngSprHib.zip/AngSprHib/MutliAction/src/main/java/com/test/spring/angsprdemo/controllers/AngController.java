package com.test.spring.angsprdemo.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.spring.angsprdemo.models.Multi;
import com.test.spring.angsprdemo.repositories.MultiRepository;

	@RestController
	public class AngController {

	    @Autowired
	    MultiRepository multiRepository;

	    @RequestMapping(method=RequestMethod.GET, value="/multis")
	    public Iterable<Multi> multi() {
	        return multiRepository.findAll();
	    }

	    @RequestMapping(method=RequestMethod.GET, value="/multis/status/{status}")
	    public Iterable<Multi> multibystatus(@PathVariable String status) {
	        if("All".equals(status))
		        return multiRepository.findAll();
	        else
	        	return multiRepository.findByStatus(status);
	    }
	    
	    @RequestMapping(method=RequestMethod.GET, value="/multis/priority/{priority}")
	    public Iterable<Multi> multipriority(@PathVariable String priority) {
	    	if("All".equals(priority))
		        return multiRepository.findAll();
	        else
	        	return multiRepository.findByPriority(priority);
	    }
	    
	    @RequestMapping(method=RequestMethod.POST, value="/multis")
	    public Multi save(@RequestBody Multi multi) {
	    	multiRepository.save(multi);
	        return multi;
	    }

	    @RequestMapping(method=RequestMethod.GET, value="/multis/{id}")
	    public Optional<Multi> show(@PathVariable String id) {
	        return multiRepository.findById(id);
	    }

	    @RequestMapping(method=RequestMethod.PUT, value="/multis/{id}")
	    public Multi update(@PathVariable String id, @RequestBody Multi multi) {
	        
	    	Optional<Multi> multiOpt = multiRepository.findById(id);
	    	Multi t = multiOpt.get();
	        if(multi.getTask() != null)
	            t.setTask(multi.getTask());
	        if(multi.getTaskDetails() != null)
	            t.setTaskDetails(multi.getTaskDetails());
	        if(multi.getPriority() != null)
	            t.setPriority(multi.getPriority());
	        if(multi.getStatus() != null)
	            t.setStatus(multi.getStatus());
	        multiRepository.save(t);
	        return multi;
	    }

	    @RequestMapping(method=RequestMethod.DELETE, value="/multis/{id}")
	    public String delete(@PathVariable String id) {
	        Optional<Multi> multi = multiRepository.findById(id);
	        multiRepository.delete(multi.get());
	        return "";
	    }
	}
